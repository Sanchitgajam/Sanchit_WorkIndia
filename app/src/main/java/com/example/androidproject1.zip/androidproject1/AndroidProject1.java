package com.example.androidproject1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AndroidProject1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_project1);
    }
}